# Triển khai QLDA lên Google Apps Script

Thư mục này là gói triển khai gồm `code.gs`, `Index.html` và `appsscript.json`; tệp này hướng dẫn thao tác deploy.

## Cập nhật gói sau khi sửa giao diện

Tại thư mục gốc dự án, chạy:

```powershell
npm run build:gas
```

Lệnh này build giao diện và ghi bản HTML tự chứa mới vào `QLDA/Index.html`.

## Thiết lập lần đầu

1. Tạo một Google Apps Script project, bật hiển thị `appsscript.json`, rồi đưa các tệp trong thư mục `QLDA` vào project với đúng tên.
2. Trong **Project Settings → Script Properties**, thêm `EDIT_PASSWORD` với mật khẩu quản trị mong muốn.
3. Chạy hàm `setupAll()` trong editor và cấp quyền truy cập Google Sheets, Drive.
4. Kiểm tra kết quả chạy để lấy liên kết Google Sheets và thư mục Drive `QLDA - Ảnh sai phạm`.
5. Tạo deployment kiểu **Web app**, chạy với tư cách chủ sở hữu (owner), rồi chọn phạm vi truy cập phù hợp với tổ chức.

Ảnh sai phạm được lưu trong thư mục Drive; Google Sheets chỉ nhận URL ảnh. Để hiển thị trong ứng dụng, mỗi ảnh được chia sẻ ở chế độ **Anyone with the link – Viewer**. Người có liên kết ảnh có thể xem ảnh, vì vậy không tải lên hình ảnh cần giữ riêng tư.

## API công khai

API đọc dữ liệu công khai, không yêu cầu API key. `GET` tới URL deployment `/exec?action=getData` trả về toàn bộ dự án, nhật ký, thông báo và loại kế hoạch. Mỗi dự án có thêm `imageLinks` tổng hợp ảnh dự án, ảnh nhật ký và ảnh sai phạm; mỗi nhật ký cũng có `imageLinks` chứa link ảnh nhật ký và tất cả ảnh trong biên bản sai phạm. Các bộ dữ liệu dự án/nhật ký vẫn giữ nguyên đầy đủ thông tin đã lưu; ảnh được trả dưới dạng URL công khai để hệ thống gọi API hiển thị, không nhúng binary/base64. `GET` `/exec?action=getProjects` chỉ trả danh sách dự án kèm link ảnh. URL `/exec` không có action API sẽ hiển thị giao diện. Có thể dùng `POST` JSON với `{"action":"getData"}` hoặc `{"action":"getProjects"}` để lấy cùng dữ liệu.

Ví dụ PowerShell:

```powershell
Invoke-RestMethod -Method Get -Uri "YOUR_APPS_SCRIPT_WEB_APP_URL/exec?action=getData"
```

Vì endpoint công khai, bất kỳ ai có URL đều có thể đọc toàn bộ số liệu và các thông tin trong nhật ký/thông báo. Chỉ triển khai nếu dữ liệu được phép công khai. Link ảnh vẫn tuân theo quyền chia sẻ của Google Drive; ảnh hiện đặt “Anyone with the link – Viewer” có thể được xem bởi bất kỳ ai có link.

Phần biên bản sai phạm cho phép chọn/chụp và tải nhiều ảnh trong một lần; mỗi ảnh tối đa 8 MB, hỗ trợ JPEG, PNG, WebP và GIF. Ảnh tải lên được chia sẻ Anyone with the link – Viewer. Khi gỡ ảnh hoặc xóa nhật ký có ảnh, Apps Script tự chuyển ảnh cũ thuộc thư mục quản lý vào thùng rác Drive sau khi cập nhật Sheets thành công. Ảnh mới tải lên nhưng bị gỡ hoặc biểu mẫu bị hủy cũng được dọn khỏi Drive. Bản xem trước hiển thị tất cả ảnh; bấm ảnh trong chi tiết biên bản sẽ mở ảnh lớn trên nền tối, có thể đóng bằng nút X, nhấp nền hoặc phím Esc. Giao diện điện thoại khóa thao tác phóng to/thu nhỏ bằng cử chỉ.

Khi triển khai bản cập nhật, chạy lại `npm run build:gas`, cập nhật `Index.html` và `code.gs` trong Apps Script, sau đó tạo phiên bản deployment mới.
